
import 'package:flutter/material.dart';

abstract class AppColors {

  static const darkPrimary = Color.fromARGB(255, 47, 207, 114); //0xff5f7760
  static const darkSecondary = Color.fromARGB(255, 255, 233, 110);
  static const darkPrimaryText = Color(0XFFFFFFFF); //#4b644a
  static const darkSecondaryText = Color(0XFF95A1AC); //for the moon
  static const darkPrimaryBackGround = Color(0XFF182026);
  static const darkSecondaryBackGround = Color(0XFF101518);
 
}