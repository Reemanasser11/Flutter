import 'package:flutter/material.dart';
import 'package:public_transet/appcolors.dart';

class HomePage extends StatelessWidget {
  final TextEditingController _currentLocationController = TextEditingController();
  final TextEditingController _destinationController = TextEditingController();

  HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkPrimaryBackGround,
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 50, 20, 20),
        children: [
          _buildLocationInputField("Enter your current location", _currentLocationController),
          const SizedBox(height: 10),
          _buildDestenaionInputField("Enter your destination", _destinationController),
          const SizedBox(height: 20),
          _buildTransportationGridView(),
          const SizedBox(height: 20),
          _buildNextButton(context),
        ],
      ),
    );
  }

  Widget _buildLocationInputField(String labelText, TextEditingController controller) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Text(labelText, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w500)),
        ),
        TextField(
          style: const TextStyle(color:AppColors.darkPrimaryText ),
          cursorColor: AppColors.darkPrimary,
          
          controller: controller,
          decoration: const InputDecoration(
            focusedBorder: OutlineInputBorder(
      borderSide: BorderSide(color: Colors.white),),
            labelText: 'Enter location',labelStyle: TextStyle(color: AppColors.darkSecondaryText),
            border: OutlineInputBorder(),
          ),
        ),
      ],
    );
  }

  Widget _buildDestenaionInputField(String labelText, TextEditingController controller) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Text(labelText, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w500)),
        ),
        TextField(
          style: const TextStyle(color:AppColors.darkPrimaryText ),
          cursorColor: AppColors.darkPrimary,
          controller: controller,
          decoration: const InputDecoration(
            focusedBorder: OutlineInputBorder(
      borderSide: BorderSide(color: Colors.white),),
            labelText: 'Enter Destenation',labelStyle: TextStyle(color: AppColors.darkSecondaryText),
            border: OutlineInputBorder(),
          ),
        ),
      ],
    );
  }

  Widget _buildTransportationGridView() {
    return GridView.builder(
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
      ),
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: 4,
      itemBuilder: (BuildContext context, int index) {
        return Container(
          height: 150,
          width: 150,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            color: AppColors.darkSecondaryBackGround,
          ),
          child: Image.asset('assets/${index == 0 ? 'train' : index == 1 ? 'bus' : index == 2 ? 'Car' : 'motor'}.png'),
        );
      },
    );
  }

 Widget _buildNextButton(BuildContext context) {
  return Center(
    child: SizedBox(
      width: 250,
      height: 40,
      child: ElevatedButton(
        style: ButtonStyle(
          backgroundColor: MaterialStateProperty.all<Color>(AppColors.darkPrimary),
          shape: MaterialStateProperty.all<RoundedRectangleBorder>(
            RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(5),
              side: const BorderSide(color: AppColors.darkPrimary, width: 2.0),
            ),
          ),
          padding: MaterialStateProperty.all<EdgeInsetsGeometry>(
            const EdgeInsets.symmetric(horizontal: 20), // تحديد هامش أفقي
          ),
        ),
        child: const Text(
          'Next',
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.w800,
            fontFamily: AutofillHints.familyName,
          ),
        ),
        onPressed: () {
          Navigator.pushNamed(
            context,
            '/road',
            arguments: {
              'currentLocation': _currentLocationController.text,
              'destination': _destinationController.text,
            },
          );
        },
      ),
    ),
  );
}



}

