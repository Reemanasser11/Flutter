import 'package:flutter/material.dart';
import 'package:public_transet/appcolors.dart';

class ListPage extends StatelessWidget {
  const ListPage({Key? key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Available Now",
          textAlign: TextAlign.center,
          style: TextStyle(color: AppColors.darkPrimary),
        ),
        backgroundColor: AppColors.darkPrimaryBackGround,
        elevation: 2,
        shadowColor: Colors.black,
        iconTheme: const IconThemeData(color: AppColors.darkPrimary),
      ),
      backgroundColor: AppColors.darkPrimaryBackGround,
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            _buildListItem("12:00", "963452"),
            _buildListItem("12:10", "100555"),
            _buildListItem("12:20", "662298"),
            _buildListItem("12:30", "990055"),
           const SizedBox(height: 40,),
            Center(
              child: SizedBox(
                height: 40,
                width: 250,
                child: ElevatedButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(AppColors.darkPrimary),
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(5),
                        side: const BorderSide(color: AppColors.darkPrimary, width: 2.0),
                      ),
                    ),
                  ),
                  child: const Text(
                    'Done',
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.w800,
                      fontFamily: AutofillHints.familyName,
                    ),
                  ),
                  onPressed: () => Navigator.pushNamed(context, '/home'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildListItem(String time, String licensePlate) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
      decoration: BoxDecoration(
        color: AppColors.darkSecondaryBackGround,
        borderRadius: BorderRadius.circular(5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            time,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
          ),
          const SizedBox(height: 4),
          Text(
            "license plate number: '$licensePlate'",
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.darkSecondaryText),
          ),
          const SizedBox(height: 10),
          
        ],
      ),
    );
  }
}
