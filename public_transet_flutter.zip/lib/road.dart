
import 'package:flutter/material.dart';
import 'package:public_transet/appcolors.dart';

class RoadBage extends StatelessWidget {
  const RoadBage({Key? key});

  @override
  Widget build(BuildContext context) {
    final Map<String, dynamic> args = ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;

    final String currentLocation = args['currentLocation'];
    final String destination = args['destination'];

    return Scaffold(
      backgroundColor: AppColors.darkPrimaryBackGround,
      body: Stack(
        children: [
          SizedBox(
            height: double.infinity,
            width: double.infinity,
            child: Image.asset(
              'assets/AnimatePolyline.jpg',
              fit: BoxFit.cover,
            ),
          ),
          Container(
            height: 120,
            decoration: const BoxDecoration(
              color: AppColors.darkPrimaryBackGround,
              borderRadius: BorderRadius.only(bottomLeft: Radius.circular(10), bottomRight: Radius.circular(10)),
            ),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 40, 10, 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      const Icon(Icons.location_on_outlined, color:AppColors.darkPrimary),
                      const SizedBox(width: 5),
                      Text(currentLocation, style: const TextStyle(color: AppColors.darkPrimary )),
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 11),
                    child: Container(
                      height: 20,
                      width: 2,
                      color: AppColors.darkPrimary,
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      const Icon(Icons.location_on, color: AppColors.darkPrimary),
                      const SizedBox(width: 5),
                      Text(destination, style: const TextStyle(color:AppColors.darkPrimary)),
                    ],
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            bottom: 20,
            left: 0,
            right: 0,
            child: Center(
              child: SizedBox(
                height: 40,
                width: 250,
                child: ElevatedButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(AppColors.darkPrimary),
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(5),
                        side: const BorderSide(color: AppColors.darkPrimary, width: 2.0),
                      ),
                    ),
                  ),
                  child: const Text(
                    'Confirm',
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.w800,
                      fontFamily: AutofillHints.familyName,
                    ),
                  ),
                  onPressed: () => Navigator.pushNamed(context, '/list'),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

