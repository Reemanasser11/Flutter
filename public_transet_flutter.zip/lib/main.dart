import 'package:flutter/material.dart';
import 'package:public_transet/list.dart';
import 'package:public_transet/road.dart';
import 'package:public_transet/home.dart';
import 'splash_screen.dart';

void main() => runApp(const PublicTransetApp());

class PublicTransetApp extends StatelessWidget {
  const PublicTransetApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Public Transet',
      
      initialRoute: '/',
      routes: {
        '/': (context) => const SplashScreen(),
         '/home': (context) =>  HomePage(),
         '/road': (context) => const RoadBage(),
         '/list': (context) => const ListPage(),
      },
    );
  }
}
