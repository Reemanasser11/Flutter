
import 'package:flutter/material.dart';
import 'package:public_transet/appcolors.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkPrimaryBackGround,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                'assets/logo.png',
                height: 150,
                width: 450,
                fit: BoxFit.contain,
              ),
              const SizedBox(height: 10,),
              const Text(
                'Public Transet',
                style: TextStyle(
                  fontSize: 24,
                  color: AppColors.darkPrimary,
                  fontWeight: FontWeight.w900,
                  fontFamily: AutofillHints.birthdayYear,
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'Seamlessly navigate your city with Public Transet, your journey starts here.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 18,
                  color: AppColors.darkSecondaryText,
                  fontWeight: FontWeight.w500,
                  fontFamily: AutofillHints.birthdayDay,
                  height: 1.3,
                ),
              ),
              const SizedBox(height:50),
              SizedBox(
                height: 40,
                width: 250,
                child: ElevatedButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(AppColors.darkPrimary),
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(5),
                        side: const BorderSide(color: AppColors.darkPrimary, width: 2.0),
                      ),
                    ),
                  ),
                  child: const Text(
                    'Get Started',
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.w800,
                      fontFamily: AutofillHints.familyName,
                      fontSize: 16,
                    ),
                  ),
                  onPressed: () => Navigator.pushNamed(context, '/home'),
                ),
              ),
             const SizedBox(height: 20,)
            ],
          ),
        ),
      ),
    );
  }
}
