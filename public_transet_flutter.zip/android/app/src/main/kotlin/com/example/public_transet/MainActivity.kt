package com.example.public_transet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
